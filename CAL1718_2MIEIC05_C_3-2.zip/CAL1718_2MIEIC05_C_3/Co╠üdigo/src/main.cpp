#include <iostream>
#include <string>
#include "menu.h"

using namespace std;
int main()
{
	menu();
	return 0;
}
