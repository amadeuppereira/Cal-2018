var searchData=
[
  ['no_5ferror',['NO_ERROR',['../connection_8cpp.html#a258bb72419ef143530a2f8f55e7d57af',1,'connection.cpp']]]
];
