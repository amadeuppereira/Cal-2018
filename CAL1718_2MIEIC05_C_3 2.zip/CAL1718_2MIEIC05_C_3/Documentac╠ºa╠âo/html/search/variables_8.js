var searchData=
[
  ['latitude',['latitude',['../class_vertex.html#a960be3c1167e82abe7fcb81178674e5e',1,'Vertex']]],
  ['longitude',['longitude',['../class_vertex.html#a830e29c233af0899c087d9873864c477',1,'Vertex']]]
];
