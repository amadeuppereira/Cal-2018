var searchData=
[
  ['high_5ftraffic',['HIGH_TRAFFIC',['../_road_network_8h.html#a88ca92279b5d6c46600c7bbec05cd421',1,'RoadNetwork.h']]],
  ['highlighted_5fedge_5fcolor',['HIGHLIGHTED_EDGE_COLOR',['../_road_network_8h.html#a973c5f767642717d927a10c4ba7b0536',1,'RoadNetwork.h']]],
  ['highlighted_5fvertex_5fcolor',['HIGHLIGHTED_VERTEX_COLOR',['../_road_network_8h.html#a5d57b679ed7a8e206acb4b2e86534120',1,'RoadNetwork.h']]]
];
