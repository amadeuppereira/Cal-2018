var searchData=
[
  ['dark_5fgray',['DARK_GRAY',['../graphviewer_8h.html#aca56870f2285abae489635f0ee4d65e3',1,'graphviewer.h']]],
  ['default_5fedge_5fcolor',['DEFAULT_EDGE_COLOR',['../_road_network_8h.html#afc7c125091ba180d90d5c7aa19645d38',1,'RoadNetwork.h']]],
  ['default_5fvertex_5fcolor',['DEFAULT_VERTEX_COLOR',['../_road_network_8h.html#a6e6e0f0a07b275692baea5c5ea99ae45',1,'RoadNetwork.h']]]
];
