#ifndef MENU_H_
#define MENU_H_

#include <iostream>
#include <cstdlib>
#include "Interface.h"

/**
 * Menu do programa
 */
void menu();

#endif /* MENU_H_ */
