var searchData=
[
  ['link',['Link',['../classLink.html#a982a39ac15c2fcaa510c0b5a54f07da8',1,'Link']]]
];
