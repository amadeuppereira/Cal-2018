var searchData=
[
  ['latitude',['latitude',['../classVertex.html#a960be3c1167e82abe7fcb81178674e5e',1,'Vertex']]],
  ['longitude',['longitude',['../classVertex.html#a830e29c233af0899c087d9873864c477',1,'Vertex']]]
];
