var searchData=
[
  ['gray',['GRAY',['../graphviewer_8h.html#ae5f70677050eecd8909e0248e07b9e73',1,'graphviewer.h']]],
  ['green',['GREEN',['../graphviewer_8h.html#acfbc006ea433ad708fdee3e82996e721',1,'graphviewer.h']]],
  ['gv_5fheight',['GV_HEIGHT',['../Utils_8h.html#a39af482c8c6e43be2248b3ab2647ba48',1,'Utils.h']]],
  ['gv_5fwidth',['GV_WIDTH',['../Utils_8h.html#adbf4f46a396f0eda435971735dfc40cf',1,'Utils.h']]]
];
