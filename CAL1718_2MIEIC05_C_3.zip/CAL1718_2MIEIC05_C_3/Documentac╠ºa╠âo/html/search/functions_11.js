var searchData=
[
  ['vertex',['Vertex',['../classVertex.html#a379ed46a1fc16ae01d69cbd071d5d708',1,'Vertex']]]
];
